package service;

import model.Item;

public interface ItemService {
	public Item findById(int i);
}
